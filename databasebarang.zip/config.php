<?php
/**
 * using mysqli_connect for database connection
 */

$conn = mysqli_connect("localhost", "loen", "alkahfi423", "projectcv");


$mysqli = mysqli_connect($databaseHost, $databaseUsername, $databasePassword, $databaseName); 

?>