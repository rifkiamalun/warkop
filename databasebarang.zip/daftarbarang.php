<?php
// koneksi database
$conn = mysqli_connect("localhost", "loen", "alkahfi423", "projectcv");

// ambil data mahasiswa
$result = mysqli_query($conn, "SELECT * FROM kopi");

// ambil data registrasi 

//while( $rgs = mysqli_fetch_assoc($result) ) {
//	var_dump($rgs);
//}
?>
<!DOCTYPE html>
<html>
	<head>
		<title> Halaman Admin</title>
		<style>
			body {
				background-color: dodgerblue;
			}
			.header {
			background-color: #7878;
 			 padding: 30px;
 			text-align: center;
  			font-size: 35px;
  			color: white;
			border-radius: none%;
				
				
			}
			table {
				margin: 5px;
				background-color: whitesmoke;
  border-collapse: collapse;
  border-spacing: 0;
  width: 100%;
  border: 1px solid #ddd;
				
}

th, td {
  text-align: left;
  padding: 16px;
}

tr:nth-child(even) {
  background-color: #f2f2f2
}
		</style>
	</head>
	<body>

		<div class="header">
		<h1>Daftar Barang</h1>
		</div>
		<table border="1" cellpadding="10" cellspacing="0">
			<tr>
				<th>No</th>
				<th>Eksekusi</th>
				<th>Daftar Barang</th>
				<th>Jenis</th>
				<th>Harga</th>
			</tr>
			<?php $i = 1; ?>
			<?php while( $row = mysqli_fetch_assoc($result) ) : ?>
			<tr>
				<td><?= $i; ?></td>
				<td>
			<a href="edit.php?id=<?php echo $d['id']; ?>">EDIT</a>
			<a href="#">Hapus</a>
				</td>
			<td><?= $row["Kopi"]; ?></td>
			<td><?= $row["Jenis"]; ?></td>
			<td><?= $row["Harga"]; ?></td>
			</tr>
			<?php $i++; ?>
				<?php endwhile; ?>
		</table>
	</body>
</html>